package jcasino.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import jcasino.dominio.Casino;
import jcasino.dominio.Jugador;
import jcasino.dominio.Usuario;

public class VentanaInicioSesion extends JFrame {
	
	private static final long serialVersionUID = 1L;


	public VentanaInicioSesion(Casino casino) {
		// Creamos la ventana
		setTitle("Inicio de Sesión");
		setSize(450, 350);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null); 
		
		// Personalización de la ventana
		Color colorFondo = new Color(30, 30, 30);
		Color colorTexto = Color.WHITE;
		Font fuenteTitulo = new Font("Segoe UI", Font.BOLD, 20);
		Font fuenteCajas = new Font("Segoe UI", Font.PLAIN, 14);
		
		
		// Añadimos un BorderLayout a la ventana
		setLayout(new BorderLayout());
		
		// PanelCentral
		JPanel panelCentro = new JPanel();
		
		// Aplicamos un BoxLayout en el eje y 
		panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));
		
		// Creamos un borde al panel para apilar todo en el centro
		panelCentro.setBorder(BorderFactory.createEmptyBorder(20, 80, 0, 80));
		panelCentro.setBackground(colorFondo); // Aplicar color de Fondo
		
		// Creamos un label de usuario
		JLabel labelUsuario = new JLabel("Nombre de Usuario");
		labelUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);
		labelUsuario.setFont(fuenteTitulo); // Fuente del titulo
		labelUsuario.setForeground(colorTexto);
		
		// Creamos el jtextField para el campo 
		JTextField txtUsuario = new JTextField();
		txtUsuario.setMaximumSize(new Dimension(200, 25));
		txtUsuario.setFont(fuenteCajas);
				
		
		panelCentro.add(labelUsuario);
		panelCentro.add(Box.createVerticalStrut(10)); // Espacio pequeño entre label y textfield
		panelCentro.add(txtUsuario);
		
		// Label de contraseña
		JLabel labelContrasenna = new JLabel("Contraseña");
		labelContrasenna.setAlignmentX(Component.CENTER_ALIGNMENT);
		labelContrasenna.setForeground(colorTexto);
		labelContrasenna.setFont(fuenteTitulo);
		
		JPasswordField txtContrasenna = new JPasswordField();
		txtContrasenna.setMaximumSize(new Dimension(200, 25));
		txtContrasenna.setFont(fuenteCajas);
		
		panelCentro.add(Box.createVerticalStrut(30)); // Espacio grande para separar usuario y contraseña
		
		panelCentro.add(labelContrasenna);
		panelCentro.add(Box.createVerticalStrut(10));
		panelCentro.add(txtContrasenna);

		
		// Botones de inicio de sesion y registro
		JPanel panelSur = new JPanel(new FlowLayout()); 
		panelSur.setBackground(colorFondo);
		// Creamos los botones 
		JButton botonInicioSesion = new JButton("Iniciar Sesión");
		JButton botonRegistrarse = new JButton("Registrarse");
		botonInicioSesion.setFocusPainted(false);
		botonRegistrarse.setFocusPainted(false);
		
		botonInicioSesion.setBackground(new Color(46, 139, 87));
		botonInicioSesion.setForeground(Color.WHITE);
		botonRegistrarse.setBackground(new Color(46, 139, 87));
		botonRegistrarse.setForeground(Color.WHITE);
		
		Font fuenteBotones = new Font("Segoe UI", Font.BOLD, 14);
		botonInicioSesion.setFont(fuenteBotones);
		botonRegistrarse.setFont(fuenteBotones);
		
		// Boton registarse nos lleve a la ventana de registrarse
		botonRegistrarse.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				VentanaRegistro ventanaSingUp = new VentanaRegistro(casino);
				ventanaSingUp.setVisible(true); // Aparece la ventana de log In
				dispose(); // Destruye la ventana de inicio de sesion 
				
			}
		});
		
		botonInicioSesion.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String usuario = txtUsuario.getText().trim();
				String contrasenna = new String(txtContrasenna.getPassword());
				
				if (usuario.isEmpty() || contrasenna.isEmpty()) {
					JOptionPane.showMessageDialog(VentanaInicioSesion.this, "Rellena usuario y contraseña");
					return;
				}
				Usuario u = casino.iniciarSesion(usuario, contrasenna);
				
				if (u == null) {
					JOptionPane.showMessageDialog(VentanaInicioSesion.this, "Usuario o contraseña incorrectos");
				}else if(u instanceof Jugador){
					new VentanaMenuJuegos(casino, (Jugador) u);
					dispose();
				}else {
					JOptionPane.showMessageDialog(VentanaInicioSesion.this, "Has iniciado sesión como Administrador");
				}
			}
		});
		
		panelSur.add(botonInicioSesion);
		panelSur.add(botonRegistrarse);
		
		
		// Añadimos los paneles a la ventana y hacemos que se vea
		add(panelCentro, BorderLayout.CENTER);
		add(panelSur, BorderLayout.SOUTH);
		setVisible(true);
		
	}

}
